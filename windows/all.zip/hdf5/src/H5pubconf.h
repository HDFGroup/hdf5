/* src/H5config.h.  Generated automatically by configure.  */
/* src/H5config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define to empty if the keyword does not work.  */
/* #undef H5_const */

/* Define as __inline if that's what the C compiler calls it.  */
#define H5_inline __inline__

/* Define to `long' if <sys/types.h> doesn't define.  */
/* #undef H5_off_t */

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef H5_size_t */

/** constants related to time on windows,kent yang 6/18/2001**/

/* Define if your struct tm has tm_zone.  */
/* #undef H5_HAVE_TM_ZONE */

/* Define if you don't have tm_zone but do have the external array
   tzname.  */
/* define H5_HAVE_TZNAME 1 */
/*#undef H5_HAVE_TZNAME */

/* Define if `tm_gmtoff' is a member of `struct tm' */
/* #undef H5_HAVE_TM_GMTOFF */

/* Define if `__tm_gmtoff' is a member of `struct tm' */
/*#define H5_HAVE___TM_GMTOFF 1*/

/* Define if `timezone' is a global variable */
/* #undef H5_HAVE_TIMEZONE */

/* Define if `struct timezone' is defined */
/*#define H5_HAVE_STRUCT_TIMEZONE 1*/

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
/*#define H5_TIME_WITH_SYS_TIME 1*/
/** no sys/time.h can be found on windows platforms 
kent yang 6/18/2001**/

/* Define if your <sys/time.h> declares struct tm.  */
/* #undef H5_TM_IN_SYS_TIME */
/** end of time constant defination, will investigate whether this
can be ignored or simplify the source code later.
kent yang 6/18/2001 **/

/* Define if you have the ANSI C header files.  */
#define H5_STDC_HEADERS 1


/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef H5_WORDS_BIGENDIAN */

/* Define if the __attribute__(()) extension is present */
#define H5_HAVE_ATTRIBUTE 1
#undef H5_HAVE_ATTRIBUTE
/** adapted from old H5pubconf.h on windows. 
will investigate the reason later. Kent yang 6/18/2001 **/

/* Define if the compiler understands the __FUNCTION__ keyword. */
//#define H5_HAVE_FUNCTION 0

/* Define if we have parallel support */
/* #undef H5_HAVE_PARALLEL */

/* Define if we have thread safe support */
/* #undef H5_HAVE_THREADSAFE */

/* currently parallel and threadsafe are not supported on windows,
will investigate threadsafe later, kent yang 6/18/2001 */

/* Define if it's safe to use `long long' for hsize_t and hssize_t */
#define H5_HAVE_LARGE_HSIZET 1

/* Define if the HDF5 v1.2 compatibility functions are to be compiled in */
/* #undef H5_WANT_H5_V1_2_COMPAT */

/* Width for printf() for type `long long' or `__int64', us. `ll' */
#define H5_PRINTF_LL_WIDTH "L"


/* Define if `struct stat' has the `st_blocks' field */
/*#define H5_HAVE_STAT_ST_BLOCKS 1*/
/* no st_blocks are supported on windows NT platform, kent yang 6/18/2001*/

/* Define if `struct text_info' is defined */
/* #undef H5_HAVE_STRUCT_TEXT_INFO */

/* Define if `struct videoconfig' is defined */
/* #undef H5_HAVE_STRUCT_VIDEOCONFIG */ /** don't know text_info or videoconfig about,
										investigate this later. kent yang 6/18/2001*/

/* Define if the ioctl TIOCGETD is defined */
/*#define H5_HAVE_TIOCGETD 1*/

/* Define if the ioctl TIOCGWINSZ is defined */
/*#define H5_HAVE_TIOCGWINSZ 1*/ /** need investigate TIOCGETD and TIOCGWINSZ **/

/** No globus, SRB, Grid Storage and stream virtual file driver supported on windows
   yet, will investigate this later. Kent Yang 6/18/2001.*/

/* Define if the Globus GASS is defined */
/* #undef H5_HAVE_GASS */

/* Define if the SRB is defined */
/* #undef H5_HAVE_SRB */

/* Define if the Grid Storage is defined */
/* #undef H5_HAVE_GRIDSTORAGE */

/* Define if the stream virtual file driver should be compiled */
/* #undef H5_HAVE_STREAM */

/* Define if `socklen_t' is defined */
/* #undef H5_HAVE_SOCKLEN_T */
/*** end of comments for globus, SRB......*/


/*** defination of data type size ***/
/* The number of bytes in a __int64.  */
#define H5_SIZEOF___INT64 8 /*windows specified _int64 is 8-bit, kent yang 6/18/2001*/

/* The number of bytes in a char.  */
#define H5_SIZEOF_CHAR 1

/* The number of bytes in a double.  */
#define H5_SIZEOF_DOUBLE 8

/* The number of bytes in a float.  */
#define H5_SIZEOF_FLOAT 4

/* The number of bytes in a int.  */
#define H5_SIZEOF_INT 4

/* The number of bytes in a int16_t.  */
#define H5_SIZEOF_INT16_T 2

/* The number of bytes in a int32_t.  */
#define H5_SIZEOF_INT32_T 4

/* The number of bytes in a int64_t.  */
#define H5_SIZEOF_INT64_T 8

/* The number of bytes in a int8_t.  */
#define H5_SIZEOF_INT8_T 1

/* The number of bytes in a int_fast16_t.  */
#define H5_SIZEOF_INT_FAST16_T 4

/* The number of bytes in a int_fast32_t.  */
#define H5_SIZEOF_INT_FAST32_T 4

/* The number of bytes in a int_fast64_t.  */
#define H5_SIZEOF_INT_FAST64_T 8

/* The number of bytes in a int_fast8_t.  */
#define H5_SIZEOF_INT_FAST8_T 1

/* The number of bytes in a int_least16_t.  */
#define H5_SIZEOF_INT_LEAST16_T 2

/* The number of bytes in a int_least32_t.  */
#define H5_SIZEOF_INT_LEAST32_T 4

/* The number of bytes in a int_least64_t.  */
#define H5_SIZEOF_INT_LEAST64_T 8

/* The number of bytes in a int_least8_t.  */
#define H5_SIZEOF_INT_LEAST8_T 1

/* The number of bytes in a long.  */
#define H5_SIZEOF_LONG 4

/* The number of bytes in a long double.  */
#define H5_SIZEOF_LONG_DOUBLE 12

/* The number of bytes in a long long.  */
#define H5_SIZEOF_LONG_LONG 0 /*windows specified kent yang 6/18/2001*/

/* The number of bytes in a off_t.  */
#define H5_SIZEOF_OFF_T 4

/* The number of bytes in a short.  */
#define H5_SIZEOF_SHORT 2

/* The number of bytes in a size_t.  */
#define H5_SIZEOF_SIZE_T 4

/* The number of bytes in a ssize_t.  */
#define H5_SIZEOF_SSIZE_T 4

/* The number of bytes in a uint16_t.  */
#define H5_SIZEOF_UINT16_T 2

/* The number of bytes in a uint32_t.  */
#define H5_SIZEOF_UINT32_T 4

/* The number of bytes in a uint64_t.  */
/*#define H5_SIZEOF_UINT64_T 8*/

/* The number of bytes in a uint8_t.  */
#define H5_SIZEOF_UINT8_T 1

/* The number of bytes in a uint_fast16_t.  */
#define H5_SIZEOF_UINT_FAST16_T 4

/* The number of bytes in a uint_fast32_t.  */
#define H5_SIZEOF_UINT_FAST32_T 4

/* The number of bytes in a uint_fast64_t.  */
#define H5_SIZEOF_UINT_FAST64_T 8

/* The number of bytes in a uint_fast8_t.  */
#define H5_SIZEOF_UINT_FAST8_T 1

/* The number of bytes in a uint_least16_t.  */
#define H5_SIZEOF_UINT_LEAST16_T 2

/* The number of bytes in a uint_least32_t.  */
#define H5_SIZEOF_UINT_LEAST32_T 4

/* The number of bytes in a uint_least64_t.  */
#define H5_SIZEOF_UINT_LEAST64_T 8

/* The number of bytes in a uint_least8_t.  */
#define H5_SIZEOF_UINT_LEAST8_T 1

/* Define if you have the BSDgettimeofday function.  */
/* #undef H5_HAVE_BSDGETTIMEOFDAY */

/* Define if you have the GetConsoleScreenBufferInfo function.  */
/* #undef H5_HAVE_GETCONSOLESCREENBUFFERINFO */

/* Define if you have the _getvideoconfig function.  */
/* #undef H5_HAVE__GETVIDEOCONFIG */

/* Define if you have the _scrsize function.  */
/* #undef H5_HAVE__SCRSIZE */

/* Define if you have the compress2 function.  */
#define H5_HAVE_COMPRESS2 1

/* Define if you have the difftime function.  */
#define H5_HAVE_DIFFTIME 1

/* Define if you have the fork function.  */
#define H5_HAVE_FORK 1

/* Define if you have the fseek64 function.  */
/* #undef H5_HAVE_FSEEK64 */

/* Define if you have the getdents64 function.  */
/* #undef H5_HAVE_GETDENTS64 */

/* Define if you have the gethostname function.  */
#define H5_HAVE_GETHOSTNAME 1

/* Define if you have the getpwuid function.  */
/*#define H5_HAVE_GETPWUID 1 */ 
/*** no getpwuid can be found, will investigate this. kent yang 6/18/2001 ***/

/* Define if you have the getrusage function.  */
/*#define H5_HAVE_GETRUSAGE 1 */
/*** no have_getrusage can be found, will investigate this. kent yang 6/18/2001 ***/

/* Define if you have the gettextinfo function.  */
/* #undef H5_HAVE_GETTEXTINFO */

/* Define if you have the gettimeofday function.  */
//#define H5_HAVE_GETTIMEOFDAY 1

/* Define if you have the ioctl function.  */
#define H5_HAVE_IOCTL 1

/* Define if you have the longjmp function.  */
#define H5_HAVE_LONGJMP 1

/* Define if you have the lseek64 function.  */
/* #undef H5_HAVE_LSEEK64 */

/* Define if you have the setsysinfo function.  */
/* #undef H5_HAVE_SETSYSINFO */

/* Define if you have the sigaction function.  */
#define H5_HAVE_SIGACTION 1

/* Define if you have the signal function.  */
#define H5_HAVE_SIGNAL 1

/* Define if you have the snprintf function.  */
/*#define H5_HAVE_SNPRINTF 1*/ /*snprintf is written as _snprintf */
#define H5_HAVE__SNPRINTF 1
/** assume _snprintf is defined, verify this later,kent yang 6/18/2001.**/

/* Define if you have the strdup function.  */
#define H5_HAVE_STRDUP 1

/* Define if you have the system function.  */
#define H5_HAVE_SYSTEM 1

/* Define if you have the vsnprintf function.  */
/*#define H5_HAVE_VSNPRINTF 1*/ /*vsnprintf is written as _snprintf */

#define H5_HAVE__VSNPRINTF 1
/** assume _snprintf is defined, verify this later,kent yang 6/18/2001.**/
/* Define if you have the waitpid function.  */

/*#define H5_HAVE_WAITPID 1*/ /* cannot find waitpid on windows, kent 6/18/2001**/


/* Define if you have the <globus_common.h> header file.  */
/* #undef H5_HAVE_GLOBUS_COMMON_H */

/* Define if you have the <grid_storage_file.h> header file.  */
/* #undef H5_HAVE_GRID_STORAGE_FILE_H */

/* Define if you have the <io.h> header file.  */
#define  H5_HAVE_IO_H /** windows do have io.h header file.**/

/* Define if you have the <mfhdf.h> header file.  */
/*#define H5_HAVE_MFHDF_H 1*/ 
/** investigate another way to support HDF4 library later. kent yang 6/18/2001**/


/* Define if you have the <netinet/tcp.h> header file.  */
/* #undef H5_HAVE_NETINET_TCP_H */

/* Define if you have the <pdb.h> header file.  */
/* #undef H5_HAVE_PDB_H */ /** this is used by SAF library.kent 6/18/2001**/

/* Define if you have the <pthread.h> header file.  */
/* #undef H5_HAVE_PTHREAD_H */

/* Define if you have the <setjmp.h> header file.  */
#define H5_HAVE_SETJMP_H 1

/* Define if you have the <srbClient.h> header file.  */
/* #undef H5_HAVE_SRBCLIENT_H */

/* Define if you have the <stddef.h> header file.  */
#define H5_HAVE_STDDEF_H 1

/* Define if you have the <stdint.h> header file.  */
/*#define H5_HAVE_STDINT_H 1 */
/** no stdint.h is found on visual studio, kent 6/18/2001 **/

/* Define if you have the <sys/filio.h> header file.  */
/* #undef H5_HAVE_SYS_FILIO_H */

/* Define if you have the <sys/ioctl.h> header file.  */
/*#define H5_HAVE_SYS_IOCTL_H 1*/
/** No sys/inctl.h can be found on visual studio, Kent 6/18/2001 **/

/* Define if you have the <sys/proc.h> header file.  */
/* #undef H5_HAVE_SYS_PROC_H */

/* Define if you have the <sys/resource.h> header file.  */
/*#define H5_HAVE_SYS_RESOURCE_H 1*/
/** No sys/resource.h can be found on visual studio, Kent 6/18/2001 **/

/* Define if you have the <sys/socket.h> header file.  */
/*#define H5_HAVE_SYS_SOCKET_H 1 */
/** No sys/socket.h can be found on visual studio, Kent 6/18/2001 **/


/* Define if you have the <sys/stat.h> header file.  */
#define H5_HAVE_SYS_STAT_H 1

/* Define if you have the <sys/sysinfo.h> header file.  */
/* #undef H5_HAVE_SYS_SYSINFO_H */

/* Define if you have the <sys/time.h> header file.  */
/*#define H5_HAVE_SYS_TIME_H 1*/
/** No sys/time.h can be found on visual studio, Kent 6/18/2001 **/


/* Define if you have the <sys/timeb.h> header file.  */
#define H5_HAVE_SYS_TIMEB_H 1

/* Define if you have the <sys/types.h> header file.  */
#define H5_HAVE_SYS_TYPES_H 1

/* Define if you have the <unistd.h> header file.  */
/*#define H5_HAVE_UNISTD_H 1*/
/** No sys/unistd.h can be found on visual studio, Kent 6/18/2001 **/

/* Define if you have the <winsock.h> header file.  */
#define H5_HAVE_WINSOCK_H 

/* Define if you have the <zlib.h> header file.  */
#define H5_HAVE_ZLIB_H 1

/* Define if you have the SrbClient library (-lSrbClient).  */
/* #undef H5_HAVE_LIBSRBCLIENT */

/* Define if you have the crypto library (-lcrypto).  */
/* #undef H5_HAVE_LIBCRYPTO */

/* Define if you have the df library (-ldf).  */
/*#define H5_HAVE_LIBDF 1*/
/* Don't know whether df library is included on windows. kent yang 6/18/2001*/

/* Define if you have the elf library (-lelf).  */
/* #undef H5_HAVE_LIBELF */

/* Define if you have the globus_common library (-lglobus_common).  */
/* #undef H5_HAVE_LIBGLOBUS_COMMON */

/* Define if you have the globus_gaa library (-lglobus_gaa).  */
/* #undef H5_HAVE_LIBGLOBUS_GAA */

/* Define if you have the globus_gass_cache library (-lglobus_gass_cache).  */
/* #undef H5_HAVE_LIBGLOBUS_GASS_CACHE */

/* Define if you have the globus_gass_file library (-lglobus_gass_file).  */
/* #undef H5_HAVE_LIBGLOBUS_GASS_FILE */

/* Define if you have the globus_gass_transfer library (-lglobus_gass_transfer).  */
/* #undef H5_HAVE_LIBGLOBUS_GASS_TRANSFER */

/* Define if you have the globus_gass_transfer_assist library (-lglobus_gass_transfer_assist).  */
/* #undef H5_HAVE_LIBGLOBUS_GASS_TRANSFER_ASSIST */

/* Define if you have the globus_gss library (-lglobus_gss).  */
/* #undef H5_HAVE_LIBGLOBUS_GSS */

/* Define if you have the globus_gss_assist library (-lglobus_gss_assist).  */
/* #undef H5_HAVE_LIBGLOBUS_GSS_ASSIST */

/* Define if you have the globus_io library (-lglobus_io).  */
/* #undef H5_HAVE_LIBGLOBUS_IO */

/* Define if you have the grid_storage_client library (-lgrid_storage_client).  */
/* #undef H5_HAVE_LIBGRID_STORAGE_CLIENT */

/* Define if you have the grid_storage_file library (-lgrid_storage_file).  */
/* #undef H5_HAVE_LIBGRID_STORAGE_FILE */

/* Define if you have the jpeg library (-ljpeg).  */
/*#define H5_HAVE_LIBJPEG 1*/
/** currently no jpeg library is assumed to be installed.
 kent yang 6/18/2001 **/

/* Define if you have the m library (-lm).  */
/*#define H5_HAVE_LIBM 1*/
/** don't know m library. kent yang 6/18/2001 **/

/* Define if you have the mfhdf library (-lmfhdf).  */
/*#define H5_HAVE_LIBMFHDF 1 */
/** don't include mfhdf library implicitly. kent yang 6/18/2001 **/

/* Define if you have the mpi library (-lmpi).  */
/* #undef H5_HAVE_LIBMPI */

/* Define if you have the mpich library (-lmpich).  */
/* #undef H5_HAVE_LIBMPICH */

/* Define if you have the mpio library (-lmpio).  */
/* #undef H5_HAVE_LIBMPIO */

/* Define if you have the nsl library (-lnsl).  */
/*#define H5_HAVE_LIBNSL 1*/
/** don't know nsl library. investigate this later.
kent yang 6/18/2001. **/

/* Define if you have the pdb library (-lpdb).  */
/* #undef H5_HAVE_LIBPDB */

/* Define if you have the pthread library (-lpthread).  */
/* #undef H5_HAVE_LIBPTHREAD */

/* Define if you have the silo library (-lsilo).  */
/* #undef H5_HAVE_LIBSILO */

/* Define if you have the socket library (-lsocket).  */
/* #undef H5_HAVE_LIBSOCKET */

/* Define if you have the ssl library (-lssl).  */
/* #undef H5_HAVE_LIBSSL */

/* Define if you have the z library (-lz).  */
#define H5_HAVE_LIBZ 1
#define H5_HAVE_COMPRESS2 1


/* Define to `long' if system headers don't define the ssize_t type */         

#define ssize_t long    
/** adapted from old h5pubconf.h kent yang 6/18/2001 **/



/* inline is a keyword in C++. If this is a C++ compiler, undefine it */
#if defined(__cplusplus) && defined(inline)
#undef inline
#endif
