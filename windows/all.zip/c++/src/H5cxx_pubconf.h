/*
 * This file is manually generated in Linux by configure, but must be
 * manually maintained in Windows.
 */
 

/* Define if offsetof extension is present */
#define H5_CXX_HAVE_OFFSETOF 1

